#pragma once

namespace GlobalConstants
{
	constexpr int MAX_BITS_IN_BUCKET = 8;
	constexpr int MIN_BITS_COUNT = 0;
	constexpr int DEFAULT_BITS_COUNT_VALUE = 2;
}
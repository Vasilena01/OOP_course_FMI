#pragma once

namespace GlobalConstants
{
	extern int MAX_POINTS_ARR_SIZE;
	constexpr int POINTS_COUNT_CONST = 65536;
}